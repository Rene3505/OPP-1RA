
package com.mycompany.eva1_5_vehiculo;


public class EVA1_5_VEHICULO {

    public static void main(String[] args) {
        Vehiculo vehiculo = new Vehiculo();
        vehiculo.setMarca("Ford");
        vehiculo.setModelo("Mustang");
        vehiculo.setYear(1970);
        vehiculo.setColor("Azul");
        vehiculo.setKilometraje(100000);
        vehiculo.setPrecio(100000);
        
        Vehiculo[] agencia = new Vehiculo[10];
        for (int i= 0; 1< agencia.length; i++){
        agencia[i] = new Vehiculo();
        agencia[i].setMarca("Ford");
        agencia[i].setModelo("Mustang");
        agencia[i].setYear(1970);
        agencia[i].setColor("Azul");
        agencia[i].setKilometraje(100000);
        agencia[i].setPrecio(100000);
        }
        
        
    }
}
