
package eva1_4_encapsulamiento;


public class EVA1_4_ENCAPSULAMIENTO {


    public static void main(String[] args) {

    }
    
}
