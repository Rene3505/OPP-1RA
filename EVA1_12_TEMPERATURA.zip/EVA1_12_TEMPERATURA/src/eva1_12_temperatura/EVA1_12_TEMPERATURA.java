
package eva1_12_temperatura;


public class EVA1_12_TEMPERATURA {

        
    public static void main(String[] args) {
        System.out.println("50 °C = " + Temperatura.celAFahrenheit(50) +  "°F");
        System.out.println("50 °F = " + Temperatura.fahrACelsius(50) +  "°C");
        System.out.println("50 °C = " + Temperatura.celAFahrenheit(50) +  "°K");
        System.out.println("50 °K = " + Temperatura.kelACel(50) +  "°C");
        System.out.println("50 °F = " + Temperatura.fahrAKel(50) +  "°K");
        System.out.println("50 °K = " + Temperatura.kelAFahr(50) +  "°F");
    }
    
}
