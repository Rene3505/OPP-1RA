
package eva1_12_temperatura;


public class Temperatura {
    
    public static double celAFahrenheit(double celsius){
        double result;
        result = celsius * (9.0/5.0) + 32;
        return result;
        }
    
    public static double fahrACelsius(double fahrenheit){
            double result;
            result = (5.0/9.0)*(fahrenheit - 32);
            return result;
    }   
    
    public static double celAKelvin(double celsius){
        double result;
        result = celsius + 273.15;
        return result;
    }
    
    public static double kelACel(double kelvin){
            double resu;
            resu = kelvin - 273.15;
            return resu;
    }
    public static double fahrAKel(double fahrenheit){
        double resu;
        resu = (5.0/9.0) * (fahrenheit - 32) + 273.15 ;
        return resu;
    }
    public static double kelAFahr(double kelvin){
            double resu;
            resu = (9.0/5.0)*(kelvin - 273.15) + 32;
            return resu;
    }
    
}
