
package eva1_11_matematicas;


public class EVA1_11_MATEMATICAS {


    public static void main(String[] args) {
        System.out.println("PI = " + Math.PI);
        System.out.println("Valor Aleatorio = " + Math.random());
        System.out.println("Potencia (5) = " + Math.pow(5, 2));
        
                //CLASE MATEMATICAS
        System.out.println("CLASE MATEMATICAS**********");
        Matematicas mate = new Matematicas();   
        System.out.println("PI: " + mate.PI);
        System.out.println("PI: " + Matematicas.PI);
    }
    
}
