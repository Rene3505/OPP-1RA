
package eva1_11_matematicas;


public class Matematicas {
    public static final double PI = 3.14159;
}
