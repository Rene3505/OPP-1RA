
package eva1_7_constructores;

public class EVA1_7_CONSTRUCTORES {

    public static void main(String[] args) {
        
        Persona perso = new Persona();
        perso.imprimirDatos();
        
        Persona perso1 = new Persona("Juan", "Pérez", 50);
        perso1.imprimirDatos();
    }
    
}
