
package eva1_7_constructores;


public class Persona {
    //ATRIBUTOS
    private String nombre;
    private String apellido;
    private int edad;
    
    //CONSTRUCTORES
    //MODIFICADOR DE ACCESO NOMBRE_CLASE(ARGUMENTOS)(CUERPO DEL CONSTRUCTOR)
    public Persona(){
    //SE USAN PARA INICIALIZAR LOS OBJETOS
    System.out.println("EJECUCION DEL CONTRUCTOR");
    nombre = "-----";
    apellido = "-----";
    edad = -1;
    }
    
    public Persona (String nombre, String apellido, int edad){
    //this --- apuntador a todo el contenido del objeto;
    //métodos y atributos definidos a la calse, SIN IMPORTAR LOS MODIFICADORES DE ACCESO
    this.nombre = nombre;
    this.apellido = apellido;
    this.edad = edad;
    
    }
    
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String valor){
        nombre = valor;
    }

    public String getApellido(){
        return apellido;
    }
    public void setApellido(String valor){
        apellido = valor;
    }
    
    public int getEdad(){
        return edad;
    }
    public void setEdad(int valor){
        edad = valor;
    }
    
    public void imprimirDatos(){
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellido: " + apellido);
        System.out.println("Edad: " + edad);
        
    }
}
