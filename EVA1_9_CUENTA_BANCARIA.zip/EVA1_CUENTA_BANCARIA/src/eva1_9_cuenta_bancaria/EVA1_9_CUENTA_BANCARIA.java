
package eva1_9_cuenta_bancaria;


public class EVA1_9_CUENTA_BANCARIA {


    public static void main(String[] args) {
        Cuenta cuen = new Cuenta("Juan Pérez,", 5000);
        cuen.imprimirSaldo();
        cuen.retirar(1500);
        cuen.imprimirSaldo();
        cuen.ingresar(6000);
        cuen.imprimirSaldo();
        cuen.retirar(10000);
        cuen.imprimirSaldo();
    }
    
}
