
package eva1_9_cuenta_bancaria;


public class Cuenta {
    //ATRIBUTOS
    private String titular;
    private double monto;
    //CONSTRUCTORES
    public Cuenta(){
    titular = "-----";
    monto = 0;
    }
    public Cuenta (String titular, double monto){
    this.titular = titular;
    this.monto = monto;
    }
    //COMPORTAMIENTOS
    public void ingresar(double monto){
    this.monto += monto;
    }
    public void retirar(double monto){
    this.monto -= monto;
    if(this.monto<0){System.out.println("No es posible retirar este dinero, saldo insuficiente.");
        this.monto +=monto;}
        }
    public void imprimirSaldo(){
        System.out.println("Saldo: "+monto);
    }
    
}
