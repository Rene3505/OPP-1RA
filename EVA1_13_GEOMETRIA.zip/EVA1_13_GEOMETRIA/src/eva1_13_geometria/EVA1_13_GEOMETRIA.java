
package eva1_13_geometria;


public class EVA1_13_GEOMETRIA {


    public static void main(String[] args) {
        Geometria figura = new Geometria();
        figura.calcularCuadrado(2);
        figura.calcularRectangulo(3, 10);
        figura.calcularTriangulo(6, 9, 3, 4, 6);
        figura.calcularCirculo(8);
        figura.calcularRombo(9, 6);
    }
    
}
