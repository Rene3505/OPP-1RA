
package eva1_13_geometria;

public class Geometria {
    private double area;
    private double lado;
    private double lado1;
    private double lado2;
    private double lado3;
    private double base;
    private double altura;
    private double perimetro;
    private double pi;
    private double radio;
    private double diagonalMay;
    private double diagonalMen;
    private double baseMay;
    
    public void calcularCuadrado(double lado){
    area = lado*lado;
        System.out.println("El area del cuadrado es de: "+area);
    }
    public void calcularRectangulo(double base, double altura){
    area = base*altura;
    perimetro = 2*base + 2*altura;
        System.out.println("El area del rectángulo es de:"+area);
        System.out.println("El perímetro del rectángulo es de: "+perimetro);
    }
    public void calcularTriangulo(double base, double altura, double lado1, double lado2, double lado3){
    area = (base*altura)/2;
    perimetro = lado1+lado2+lado3;
        System.out.println("El area del triangulo es de: "+area);
        System.out.println("El perimetro del rectángulo es de: "+perimetro);
    }
    public void calcularCirculo(double radio){
    pi = 3.14;
    area = pi*(radio*radio);
    perimetro = 2*pi*radio;
        System.out.println("El area del círculo es de: "+ area);
        System.out.println("El perimetro del círculo es de: "+perimetro);
    }
    public void calcularRombo(double diagonalMay, double diagonalMen){
    area = (diagonalMay*diagonalMen)/2;
        System.out.println("El área del rombo es de: "+ area);
    }
    public void calcularTrapecio(double baseMay, double base, double altura){
    area = ((baseMay*base)*altura)/2;
        System.out.println("El área del trapecio es de: "+area);
    }
}
