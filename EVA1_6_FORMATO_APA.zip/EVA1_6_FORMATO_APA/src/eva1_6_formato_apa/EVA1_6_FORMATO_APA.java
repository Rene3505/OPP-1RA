
package eva1_6_formato_apa;


public class EVA1_6_FORMATO_APA {


    public static void main(String[] args) {
        APA libro = new APA();
        libro.setAutor("Franz Kafka");
        libro.setTitulo("Metamorfosis");
        libro.setEditorial("Alianza editorial");
        libro.setYear(1912);
        libro.setVolumenes(1);
        
        libro.imprimirDatos();
    }
    
}
