
package eva1_6_formato_apa;


public class APA {
    private String autor;
    private int year;
    private String titulo;
    private String editorial;
    private int volumenes;
    
    public String getAutor(){
        return autor;
    }
    public void setAutor(String valor){
        autor = valor;
    }
    
    public int getYear(){
        return year;
    }
    public void setYear(int valor){
        year = valor;
    }
  

    public String getTitulo(){
        return titulo;
    }
    public void setTitulo(String valor){
        titulo = valor;
    }

    public String getEditorial(){
        return editorial;
    }
    public void setEditorial(String valor){
        editorial = valor;
    }

    public int getVolumenes(){
        return volumenes;
    }
    public void setVolumenes(int valor){
        volumenes = valor;
    }
      
    
    public void imprimirDatos(){
        System.out.println("Título: "+ titulo);
        System.out.println("Autor: "+ autor);
        System.out.println("Año: "+ year);
        System.out.println("Editorial: "+ editorial);
        System.out.println("Total de volúmenes: "+ volumenes);
    }
}
