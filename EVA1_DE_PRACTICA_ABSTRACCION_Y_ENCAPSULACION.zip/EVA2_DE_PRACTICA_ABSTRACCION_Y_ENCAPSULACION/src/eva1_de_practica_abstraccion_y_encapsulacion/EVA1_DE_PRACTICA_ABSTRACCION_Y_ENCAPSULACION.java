package eva1_de_practica_abstraccion_y_encapsulacion;

public class EVA1_DE_PRACTICA_ABSTRACCION_Y_ENCAPSULACION {

    public static void main(String[] args) {
        Persona perso = new Persona ();
        System.out.println(perso);
        perso.
        
    }
    
}
class Persona{
    public String nombre;
    public String apellido;
    public int edad;
}